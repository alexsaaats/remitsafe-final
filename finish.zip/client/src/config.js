export default {
  region: 'us-west-2',
  IdentityPoolId: '',
  UserPoolId: 'us-west-2_uCKj8WQdj',
  ClientId: '3oif839ghn4ft9rbmck44goep7',
    STRIPE_SECRET:'sk_test_iNpvQYjqUW2yvZAaXgmFoWAF',
    STRIPE_PUBLIC:'pk_test_9d7uiHATUXpuIOhgKUSMLYkd',
    STRIPE_CCY: 'usd'
}


