export const staticFill =


[
  {
    "id": 734903,
    "reSafeVerified": true,
    "vendorName": "Kors",
    "vendorContact": {
      "name": "Michael Kors",
      "phoneNumber": "516 767 1422",
      "email": "contact1@abc.com"
    },
    "remitInfo": {
      "bankName": "Chase",
      "streetAddress1": " 123 Train Way",
      "routingNo": "123456789",
      "accountNo": "1234567890"
    }
  },
  {
    "id": 734906,
    "reSafeVerified": true,
    "vendorName": "Target",
    "vendorContact": {
      "name": "Michael Jackson",
      "phoneNumber": "516 767 1422",
      "email": "contact1@abc.com"
    },
    "remitInfo": {
      "bankName": "Chase",
      "streetAddress1": " 123 Train Way",
      "routingNo": "123456789",
      "accountNo": "1234567890"
    }
  },
    {
        "id": 2,
        "reSafeVerified": true,
        "vendorName": "Random",
        "vendorContact": {
            "name": "Judy Bloom",
            "phoneNumber": "516 767 1422",
            "email": "contact1@abc.com"
        },
        "remitInfo": {
            "bankName": "Chase",
            "streetAddress1": " 123 Train Way",
            "routingNo": "123456789",
            "accountNo": "1234567890"
        }
    },
  {
    "id": 734904,
    "reSafeVerified": true,
    "vendorName": "NBA",
    "vendorContact": {
      "name": "Michael Jordan",
      "phoneNumber": "516 767 1422",
      "email": "contact1@abc.com"
    },
    "remitInfo": {
      "bankName": "Chase",
      "streetAddress1": " 123 Train Way",
      "routingNo": "123456789",
      "accountNo": "1234567890"
    }
  },
    {
        "id": 734905,
        "reSafeVerified": true,
        "vendorName": "Best Buy",
        "vendorContact": {
            "name": "Michael Keaton",
            "phoneNumber": "516 767 1422",
            "email": "contact1@abc.com"
        },
        "remitInfo": {
            "bankName": "Chase",
            "streetAddress1": " 123 Train Way",
            "routingNo": "123456789",
            "accountNo": "1234567890"
        }
    },
    {
        "id": 4,
        "reSafeVerified": true,
        "vendorName": "Muppets",
        "vendorContact": {
            "name": "Jim Henson",
            "phoneNumber": "516 767 1422",
            "email": "contact1@abc.com"
        },
        "remitInfo": {
            "bankName": "Chase",
            "streetAddress1": " 123 Train Way",
            "routingNo": "123456789",
            "accountNo": "1234567890"
        }
    }
];