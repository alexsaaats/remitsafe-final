export function createBut() {
    console.log("Hello Create");
}

export function deleteVenBut() {
    console.log("Hello Delete");
}

export function editVenBut() {
    console.log("Hello Edit");
}




