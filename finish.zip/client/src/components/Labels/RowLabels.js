import React, {Component} from 'react';
import Modal from '../BuyerDashboard/EditTable/editModal';
import DeleteRow from '../BuyerDashboard/EditTable/deleteRow';

const RowLabels = () => (
    <div>
        <Modal/>

    </div>

);

export default RowLabels;
