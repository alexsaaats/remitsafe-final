export { default } from "./Buyer";
