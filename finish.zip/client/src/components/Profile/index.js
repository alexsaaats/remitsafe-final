export { default } from "./AddProfile";
