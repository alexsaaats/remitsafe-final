import React from 'react';

let WelcomeMessage = props => (
    <div>
<h3>{`Welcome, ${props.email} you are successfully logged into your account`}</h3>
</div>
);


export default WelcomeMessage;
